<?php

//SITE GLOBAL CONFIGURATION
$email = "www.rubyjazzdesign@gmail.com";   //<-- Your email

?>
